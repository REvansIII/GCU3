﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap4Ex14
{
    class Chap4Ex14
    {
        static void Main(string[] args)
        {
            Area();
        }

        public static void Area() {
            char again = 'N';

           
            do
            {
                Console.WriteLine("Enter the radius or 0 to quit");
                double r = double.Parse(Console.ReadLine());

                double area = Math.PI * r * r;
                Console.WriteLine("The area of the circle is {0}", area);

                Console.WriteLine("Would you like to try again?  y or n");

                 again = char.Parse(Console.ReadLine());

            } while (again == 'y' || again == 'Y');



        }

    }
    }


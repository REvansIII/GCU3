﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap4Ex16
{
    class Chap4Ex16
    {
        static void Main(string[] args)
        {
            DivideAverage();
        }

        public static void DivideAverage()
        {

            Console.WriteLine("Please enter a number");
            double x = double.Parse(Console.ReadLine());

            double r = x * .5;
            double z = 0;


            for (int i = 0; i < 10; i++)

                if (i < 10)
                {


                    z = x / r;
                    double avg = (r + z) / 2;
                    r = avg;

                    Console.WriteLine("The result of the divide and average method is {0}", r);
                   

                }
                    Console.WriteLine("The result of the Math.Sqrt method is {0}", Math.Sqrt(x));

        }
                }   

              

                

        }
    


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chap4Ex18
{
    class Chap4Ex18
    {
        static void Main(string[] args)
        {
            GCD(54, 16);

        }

        public static void GCD(int a, int b) {
            int c;
            do
            {
                c = a % b;
                a = b;
                b = c;          
                
               

             
           Console.WriteLine(c);


            } while (c > 0);

        }
    }
}
